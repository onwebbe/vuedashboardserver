#! /bin/bash
node bin/www