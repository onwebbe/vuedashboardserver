create database if not exists vuedashboard DEFAULT CHARSET utf8 COLLATE utf8_general_ci;
use vuedashboard;